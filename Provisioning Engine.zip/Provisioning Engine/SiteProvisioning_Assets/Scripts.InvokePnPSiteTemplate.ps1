<#
    Description     :   Use this PowerShell script to invoke the pnp provisioning engine on Associated site or hub site.
#>

[CmdletBinding()]
param (
    $HubSiteId,
    $PrimaryEmailID,
    $Step,
    $TargetSite,
    $TemplateFolderPath,
    $Tenant,
    $Handlers,
    $HubSiteURL
)

# Clear the Screen
Clear-Host

# Setup the Tenant Url
$TenantUrl = "https://$($Tenant).sharepoint.com"

# Setup the Site Collection URL
$SiteUrl = "https://$($Tenant).sharepoint.com/$($TargetSite)"

<#
	.Description
	Applies the Hub Site Template to the Site Collection
#>
function InvokePnPHubSiteTemplate() {
    
    # Connect to the SharePoint Site Collection
    Write-Host "Connecting to the Site Collection - $($SiteUrl)"
    Connect-PnPOnline -Url $SiteUrl -ClientId $ClientId -Tenant $TenantUniqueIdentifier -CertificatePath $CertificatePath -CertificatePassword $CertPass
    Write-Host "Connected to the Tenant - $($SiteUrl)" -ForegroundColor Green

    # Setup the Hub Site Template Name
    $HubSiteTemplateName = "HubSite-Provisioning-Template.xml"

    # Setup the Hub Site Template Path
    $HubSiteTempatePath = $TemplateFolderPath + $HubSiteTemplateName

    #  the Hub Site Template Path
    Write-Host "Hub Site Template Path $($HubSiteTempatePath)"

   
    Write-Host "Applying the Hub Site Template to the Site Collection.."
    Invoke-PnPSiteTemplate -Path $HubSiteTempatePath -Parameters @{"PrimaryEmailID" = $PrimaryEmailID } -Handlers $Handlers -ClearNavigation -ErrorAction Stop
    Write-Host "Successfully applied the Hub Site Template to the Site Collection.." -ForegroundColor Green

    
    # Disconnect the Session
    Disconnect-PnPOnline
    Write-Host "Disconnected the PnP Session from Site Collection..!"
}

<#
	.Description
	Applies the Market Site Template to the Site Collection
#>
function InvokePnPAssociatedSiteTemplate() {

    # Connect to the SharePoint Site Collection
    Write-Host "Connecting to the Site Collection - $($SiteUrl)"
    Connect-PnPOnline -Url $SiteUrl -ClientId $ClientId -Tenant $TenantUniqueIdentifier -CertificatePath $CertificatePath -CertificatePassword $CertPass
    Write-Host "Connected to the Tenant - $($SiteUrl)" -ForegroundColor Green

    # Setup the Market Site Template Name
    $MarketSiteTemplateName = "Associated-Site-Provisioning-Template.xml"

    # Setup the Market Site Template Path
    $MarketSiteTempatePath = $TemplateFolderPath + $MarketSiteTemplateName

    Write-Host "Applying the Associated-Site Template to the Site Collection.."
    Invoke-PnPSiteTemplate -Path $MarketSiteTempatePath -Parameters @{"PrimaryEmailID" = $PrimaryEmailID; "HubSiteURL" = $HubSiteURL } -Handlers $Handlers -ErrorAction Stop
    Write-Host "Successfully applied the Associated-Site Template to the Site Collection.." -ForegroundColor Green

    # Disconnect the Session
    Disconnect-PnPOnline
    Write-Host "Disconnected the PnP Session from Site Collection..!"
}


try {
    Write-Host "Execution of the PowerShell script started to apply the PnP Site Template..!"

    # Invoke the function based on user selection
    switch ($Step) {
        '1' {
            # Apply the Hub Site Template if the site collection is a hub site
            InvokePnPHubSiteTemplate
        }
        '2' {
            # Apply the site template if the site collection is market site
            InvokePnPMarketSiteTemplate
        }
    }

    Write-Host "Execution of the PowerShell script ended to apply the PnP Site Template..!"
}
# Exception handling
catch {
    # Log the error message in console
    Write-Error -Message $Error[0].Exception.Message -ErrorAction Stop
}