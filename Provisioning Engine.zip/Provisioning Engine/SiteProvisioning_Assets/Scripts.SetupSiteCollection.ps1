﻿<#
Description     :   Use this powershell script to perform following activities:
					1. Setup the Hub Site
                        - Create the Site Collection
                        - Register it as a Hub Site in the Tenant                        
                        - Setup the Property Bags
                    2. Setup the Associated Site
                        - Create the Site Collection and associate it with the hub site
                        - Setup the Property Bags
#>

[CmdletBinding()]
param (
    $DefaultLocaleId,
    $DefaultTimeZone,
    $HubSiteId,
    $SiteTitle,
    $SiteOwner,
    $Step,
    $TargetSite,
    $Tenant
)

# Clear the Screen
Clear-Host

# Setup the Tenant Url
$TenantUrl = "https://$($Tenant).sharepoint.com"

# Setup the Site Collection URL
$SiteUrl = "https://$($Tenant).sharepoint.com/$($TargetSite)"

<#
    .Description
    Create the Communication Site, Register it as a Hub Site, Enable Site Collection App Catalog and Add the Property Bags
#>
function SetupHubSite() {
    try {
        # Connect to the SharePoint Tenant using the Certificate details
        Write-Host "Connecting to the Tenant - $($TenantUrl)"
        Connect-PnPOnline -Url $TenantUrl -ClientId $ClientId -Tenant $TenantUniqueIdentifier -CertificatePath $CertificatePath -CertificatePassword $CertPass -ErrorAction Stop
        Write-Host "Connected to the Tenant - $($TenantUrl)" -ForegroundColor Green

        # Create the Site Collection
        Write-Host 'Creating Site Collection..!'
        New-PnPSite -Type CommunicationSite -Title $SiteTitle -Url $SiteUrl -Lcid $DefaultLocaleId -Owner $SiteOwner -TimeZone $DefaultTimeZone -Wait -ErrorAction Stop
        Write-Host 'Site Collection Created successfully..!' -ForegroundColor Green
    
        # Register it as a Hub Site if Hub Site Flag is true
        Write-Host "Registering the $($SiteUrl) Site as hub site"
        Register-PnPHubSite -Site $SiteUrl -Principals $SiteOwner -ErrorAction Stop
        Write-Host "Registered the $($SiteUrl) Site as hub site in $($TenantUrl) Tenant" -ForegroundColor Green

        # Wait for 60 Seconds i.e. 1 Minute
        Start-Sleep -Seconds 60

        # Test the newly created site collection
        Write-Host "Verifying newly created Site Collection..!"
        Test-PnPSite -Identity $SiteUrl
        Write-Host "Successfully verified the site collection: $($SiteUrl)"

        # Disconnect the Connection from the SharePoint Tenant
        Disconnect-PnPOnline

        # Connect to the newly created Site collection using the certificate details
        Write-Host 'Connecting to Hub Site..'
        Connect-PnPOnline -Url $SiteUrl -ClientId $ClientId -Tenant $TenantUniqueIdentifier -CertificatePath $CertificatePath -CertificatePassword $CertPass -ErrorAction Stop

        # Add the Site Collection Level App Catalog
        Write-Host 'Creating Local App Catalog'
        Add-PnPSiteCollectionAppCatalog -Site $SiteUrl -ErrorAction Stop
        Write-Host 'App Catalog is created successfully' -ForegroundColor Green

        # Wait for 60 Seconds i.e. 1 Minute
        Start-Sleep -Seconds 60
        
        # Disable the NoScript for newly created SitE Collection
        Write-Host "Disabling NoScript "
        Set-PnPTenantSite -Url $SiteUrl -NoScriptSite:$false -ErrorAction Stop
        Write-Host "Disabled NoScript" -ForegroundColor Green

        # Setup the Property Bag for Key: VFSiteType
        Write-Host "Adding Propertybag - Key: PropertyBag1"
        Set-PnPPropertyBagValue -Key "PropertyBag1" -Value "PropertyBag_Value1" -ErrorAction Stop

        # Setup the Property Bag for Key
        Write-Host "Adding Indexed Propertybag - Key: PropertyBag2"
        Set-PnPPropertyBagValue -Key "PropertyBag2" -Value 'PropertyBag_Valu2' -Indexed -ErrorAction Stop

        # Enable the NoScript for newly created SitE Collection
        Write-Host "Enabling NoScript"
        Set-PnPTenantSite -Url $SiteUrl -NoScriptSite -ErrorAction Stop
        Write-Host "Enabled NoScript" -ForegroundColor Green

        # Disconnect the Connection from the newly created Site Collection
        Disconnect-PnPOnline
    }
    # Exception handling
    catch {
        # Log the error message in console
        Write-Error -Message $Error[0].Exception.Message -ErrorAction Stop
    }
}

<#
    .Description
    Create the Communication Site, Associate it with Hub Site, Enable Site Collection App Catalog and Add the Property Bags
#>
function SetupAssociatedSite() {
    try {
        # Connect to the SharePoint Tenant using the Certificate details
        Write-Host "Connecting to the Tenant - $($TenantUrl)"
        Connect-PnPOnline -Url $TenantUrl -ClientId $ClientId -Tenant $TenantUniqueIdentifier -CertificatePath $CertificatePath -CertificatePassword $CertPass -ErrorAction Stop
        Write-Host "Connected to the Tenant - $($TenantUrl)" -ForegroundColor Green

        # Create the Site collection and associate it with hub site
        Write-Host 'Creating Site Collection..!'
        New-PnPSite -Type CommunicationSite -Title $SiteTitle -Url $SiteUrl -HubSiteId $HubSiteId -Lcid $DefaultLocaleId -Owner $SiteOwner -TimeZone $DefaultTimeZone -Wait -ErrorAction Stop
        Write-Host 'Site Collection Created successfully..!' -ForegroundColor Green

        # Wait for 60 Seconds i.e. 1 Minute
        Start-Sleep -Seconds 60

        # Test the newly created site collection
        Write-Host "Verifying newly created Site Collection..!"
        Test-PnPSite -Identity $SiteUrl
        Write-Host "Successfully verified the site collection: $($SiteUrl)"

        # Disconnect the Connection from the SharePoint Tenant
        Disconnect-PnPOnline

        # Connect to the newly created Site collection using the certificate details
        Write-Host 'Connecting to Associated Site..'
        Connect-PnPOnline -Url $SiteUrl -ClientId $ClientId -Tenant $TenantUniqueIdentifier -CertificatePath $CertificatePath -CertificatePassword $CertPass -ErrorAction Stop

        # Add the Site Collection Level App Catalog
        Write-Host 'Creating Local App Catalog'
        Add-PnPSiteCollectionAppCatalog -Site $SiteUrl -ErrorAction Stop
        Write-Host 'App Catalog is created successfully' -ForegroundColor Green

        # Wait for 60 Seconds i.e. 1 Minute
        Start-Sleep -Seconds 60

        # Disable the NoScript for newly created SitE Collection
        Write-Host "Disabling NoScript "
        Set-PnPTenantSite -Url $SiteUrl -NoScriptSite:$false -ErrorAction Stop
        Write-Host "Disabled NoScript" -ForegroundColor Green

        # Setup the Property Bag for Key: VFSiteType
        Write-Host "Adding Propertybag - Key: PropertyBag1"
        Set-PnPPropertyBagValue -Key "PropertyBag1" -Value "PropertyBag_Value1" -ErrorAction Stop

        # Setup the Property Bag for Key
        Write-Host "Adding Indexed Propertybag - Key: PropertyBag2"
        Set-PnPPropertyBagValue -Key "PropertyBag2" -Value 'PropertyBag_Valu2' -Indexed -ErrorAction Stop

        # Enable the NoScript for newly created SitE Collection
        Write-Host "Enabling NoScript"
        Set-PnPTenantSite -Url $SiteUrl -NoScriptSite -ErrorAction Stop
        Write-Host "Enabled NoScript" -ForegroundColor Green

        # Disconnect the Connection from the newly created Site Collection
        Disconnect-PnPOnline

      
    }
    # Exception handling
    catch {
        # Log the error message in console
        Write-Error -Message $Error[0].Exception.Message -ErrorAction Stop
    }   
}

try {
    # Invoke the function based on user selection
    switch ($Step) {
        '1' {
            SetupHubSite
        }
        '2' {
            SetupAssociatedSite
        }
    }
}
# Exception handling
catch {
    # Log the error message in console
    Write-Error -Message $Error[0].Exception.Message -ErrorAction Stop
}
